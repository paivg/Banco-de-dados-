// Comandos de evidência para o mongosh (banco: catalogo, coleção: produtos).
// Rode um por vez no mongosh para tirar os prints, ou tudo de uma vez:
//   mongosh --file mongosh/comandos.js

db = db.getSiblingDB("catalogo");

print("\n--- Coleções e índices");
printjson(db.getCollectionNames());
printjson(db.produtos.getIndexes());

print("\n--- CREATE: insertOne");
db.produtos.deleteOne({ sku: "TST-0001" });
printjson(db.produtos.insertOne({
  sku: "TST-0001",
  nome: "Produto de teste (mongosh)",
  descricao: "Inserido direto pelo shell",
  categoria: "Testes",
  preco: 10.5,
  estoque: 3,
  tags: ["teste"],
  fornecedor: { nome: "Fornecedor Teste", cidade: "Tupã" },
  especificacoes: { cor: "azul" },
  ativo: true,
  criado_em: new Date(),
  atualizado_em: new Date()
}));

print("\n--- READ: find com filtro, projeção e ordenação");
printjson(db.produtos.find(
  { categoria: "Eletrônicos", preco: { $lt: 300 } },
  { _id: 0, sku: 1, nome: 1, preco: 1, estoque: 1 }
).sort({ preco: 1 }).toArray());

print("\n--- READ: campo de documento embutido e elemento de array");
printjson(db.produtos.find(
  { "fornecedor.cidade": "Tupã", tags: "iot" },
  { _id: 0, sku: 1, nome: 1, fornecedor: 1, tags: 1 }
).toArray());

print("\n--- READ: expressão regular e contagem");
printjson(db.produtos.find({ nome: /sensor/i }, { _id: 0, sku: 1, nome: 1 }).toArray());
print("Total de documentos: " + db.produtos.countDocuments());

print("\n--- UPDATE: $set, $inc e $addToSet");
printjson(db.produtos.updateOne(
  { sku: "TST-0001" },
  { $set: { preco: 12.9, atualizado_em: new Date() }, $inc: { estoque: 7 }, $addToSet: { tags: "atualizado" } }
));
printjson(db.produtos.findOne({ sku: "TST-0001" }));

print("\n--- AGGREGATE: resumo por categoria");
printjson(db.produtos.aggregate([
  { $group: {
      _id: "$categoria",
      produtos: { $sum: 1 },
      itens_em_estoque: { $sum: "$estoque" },
      valor_em_estoque: { $sum: { $multiply: ["$preco", "$estoque"] } },
      preco_medio: { $avg: "$preco" }
  } },
  { $sort: { valor_em_estoque: -1 } }
]).toArray());

print("\n--- DELETE: deleteOne");
printjson(db.produtos.deleteOne({ sku: "TST-0001" }));
print("Total de documentos: " + db.produtos.countDocuments());
