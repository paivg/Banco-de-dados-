@echo off
title Catalogo de Produtos - Flask + MongoDB
cd /d "%~dp0python-web"

where python >nul 2>nul
if errorlevel 1 (
  echo [ERRO] Python nao encontrado. Instale em https://www.python.org/downloads/ marcando "Add python.exe to PATH".
  pause
  exit /b 1
)

if not exist .venv (
  echo Criando ambiente virtual...
  python -m venv .venv
)
call .venv\Scripts\activate.bat

echo Instalando dependencias (Flask e PyMongo)...
python -m pip install -q -r requirements.txt
if errorlevel 1 (
  echo [ERRO] Falha ao instalar as dependencias.
  pause
  exit /b 1
)

echo Inserindo produtos de exemplo no MongoDB...
python seed.py
if errorlevel 1 (
  echo.
  echo [ERRO] Nao foi possivel conectar no MongoDB em mongodb://localhost:27017.
  echo Verifique se o MongoDB Community Server esta instalado e se o servico "MongoDB" esta iniciado.
  pause
  exit /b 1
)

echo.
echo Abrindo http://localhost:5000/dashboard ... (feche esta janela para parar a aplicacao)
start "" cmd /c "timeout /t 3 >nul & start http://localhost:5000/dashboard"
python app.py
pause
