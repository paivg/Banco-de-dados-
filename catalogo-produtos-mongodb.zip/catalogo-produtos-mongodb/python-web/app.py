"""Catálogo de Produtos - CRUD com Flask + PyMongo (MongoDB).

Atividade Prática IAL-215 - Banco de Dados NoSQL.
"""
import os
import re
import unicodedata
from pprint import pformat
from datetime import datetime, timezone

from bson import ObjectId
from bson.errors import InvalidId
from flask import Flask, abort, flash, redirect, render_template, request, url_for
from pymongo import ASCENDING, DESCENDING, MongoClient, TEXT
from pymongo.errors import DuplicateKeyError

MONGO_URI = os.environ.get("MONGO_URI", "mongodb://localhost:27017")
MONGO_DB = os.environ.get("MONGO_DB", "catalogo")

app = Flask(__name__)
app.secret_key = os.environ.get("SECRET_KEY", "ial215-dev")

client = MongoClient(MONGO_URI, serverSelectionTimeoutMS=3000)
db = client[MONGO_DB]
produtos = db["produtos"]

PASTA_FOTOS = os.path.join(app.static_folder, "uploads")
os.makedirs(PASTA_FOTOS, exist_ok=True)
EXTENSOES_FOTO = {"png", "jpg", "jpeg", "webp", "gif"}
app.config["MAX_CONTENT_LENGTH"] = 5 * 1024 * 1024  # fotos de até 5 MB

# Ícone mostrado quando o produto não tem foto: primeiro pela palavra no nome, depois pela categoria.
ICONES_NOME = [
    ("cadeira", "🪑"), ("poltrona", "🛋️"), ("sofa", "🛋️"), ("mouse", "🖱️"), ("teclado", "⌨️"),
    ("monitor", "🖥️"), ("webcam", "📷"), ("camera", "📷"), ("notebook", "💻"), ("laptop", "💻"),
    ("celular", "📱"), ("smartphone", "📱"), ("fone", "🎧"), ("headset", "🎧"), ("impressora", "🖨️"),
    ("caderno", "📓"), ("caneta", "🖊️"), ("lapis", "✏️"), ("papel", "📄"), ("livro", "📚"),
    ("cafeteira", "☕"), ("cafe", "☕"), ("panela", "🍳"), ("ventilador", "🌀"), ("lampada", "💡"),
    ("sensor", "📡"), ("meteorolog", "🌦️"), ("bateria", "🔋"), ("pilha", "🔋"),
    ("camiseta", "👕"), ("tenis", "👟"), ("relogio", "⌚"), ("mochila", "🎒"),
]
ICONES_CATEGORIA = [
    ("eletr", "🔌"), ("escrit", "🗂️"), ("casa", "🏠"), ("agro", "🌱"), ("aliment", "🍎"),
    ("roupa", "👕"), ("vestu", "👕"), ("livr", "📚"), ("brinq", "🧸"), ("test", "🧪"),
]


def sem_acento(texto):
    normal = unicodedata.normalize("NFKD", str(texto or "").lower())
    return "".join(c for c in normal if not unicodedata.combining(c))


@app.template_global("icone")
def icone(nome="", categoria=""):
    nome, categoria = sem_acento(nome), sem_acento(categoria)
    for trecho, simbolo in ICONES_NOME:
        if trecho in nome:
            return simbolo
    for trecho, simbolo in ICONES_CATEGORIA:
        if trecho in categoria:
            return simbolo
    return "📦"


def salvar_foto(arquivo, sku):
    """Grava a foto enviada em static/uploads e devolve o nome do arquivo (ou None)."""
    if not arquivo or not arquivo.filename:
        return None
    extensao = arquivo.filename.rsplit(".", 1)[-1].lower() if "." in arquivo.filename else ""
    if extensao not in EXTENSOES_FOTO:
        flash("Foto ignorada: use PNG, JPG, WEBP ou GIF.", "erro")
        return None
    base = re.sub(r"[^A-Za-z0-9_-]", "", sku) or "produto"
    nome = f"{base}-{int(datetime.now().timestamp())}.{extensao}"
    arquivo.save(os.path.join(PASTA_FOTOS, nome))
    return nome

POR_PAGINA = 8
ESTOQUE_BAIXO = 5  # até esta quantidade o produto aparece em "repor estoque"
FAIXAS_PRECO = [0, 50, 100, 250, 500, 1000]
ROTULOS_FAIXA = {0: "até R$ 50", 50: "R$ 50 a 100", 100: "R$ 100 a 250", 250: "R$ 250 a 500",
                 500: "R$ 500 a 1.000", "acima": "acima de R$ 1.000"}
ORDENACOES = {
    "nome": ("nome", ASCENDING),
    "preco_asc": ("preco", ASCENDING),
    "preco_desc": ("preco", DESCENDING),
    "estoque": ("estoque", ASCENDING),
    "recentes": ("criado_em", DESCENDING),
}


def criar_indices():
    """Índices: SKU único, texto (nome/descrição) e categoria."""
    produtos.create_index([("sku", ASCENDING)], unique=True, name="sku_unico")
    produtos.create_index(
        [("nome", TEXT), ("descricao", TEXT)],
        default_language="portuguese",
        name="texto_nome_descricao",
    )
    produtos.create_index([("categoria", ASCENDING), ("preco", ASCENDING)], name="categoria_preco")


def agora():
    return datetime.now(timezone.utc)


def obter_id(id_texto):
    try:
        return ObjectId(id_texto)
    except (InvalidId, TypeError):
        abort(404)


def buscar_ou_404(id_texto):
    doc = produtos.find_one({"_id": obter_id(id_texto)})
    if doc is None:
        abort(404)
    return doc


def ler_formulario(form):
    """Converte o formulário HTML em um documento do MongoDB.

    Devolve (documento, lista_de_erros).
    """
    erros = []
    sku = form.get("sku", "").strip().upper()
    nome = form.get("nome", "").strip()
    categoria = form.get("categoria", "").strip()
    if not sku:
        erros.append("Informe o SKU.")
    if not nome:
        erros.append("Informe o nome.")
    if not categoria:
        erros.append("Informe a categoria.")

    try:
        preco = round(float(form.get("preco", "").replace(",", ".")), 2)
        if preco < 0:
            raise ValueError
    except ValueError:
        preco = 0.0
        erros.append("Preço inválido.")

    try:
        estoque = int(form.get("estoque", "0") or 0)
        if estoque < 0:
            raise ValueError
    except ValueError:
        estoque = 0
        erros.append("Estoque inválido.")

    # Array: "a, b, c" -> ["a", "b", "c"]
    tags = [t.strip().lower() for t in form.get("tags", "").split(",") if t.strip()]

    # Documento embutido com campos dinâmicos: uma linha "chave: valor" por atributo.
    especificacoes = {}
    for linha in form.get("especificacoes", "").splitlines():
        if ":" in linha:
            chave, valor = linha.split(":", 1)
            chave = chave.strip().replace(".", "_").replace("$", "")
            if chave and valor.strip():
                especificacoes[chave] = valor.strip()

    doc = {
        "sku": sku,
        "nome": nome,
        "descricao": form.get("descricao", "").strip(),
        "categoria": categoria,
        "preco": preco,
        "estoque": estoque,
        "tags": tags,
        "fornecedor": {
            "nome": form.get("fornecedor_nome", "").strip(),
            "cidade": form.get("fornecedor_cidade", "").strip(),
        },
        "especificacoes": especificacoes,
        "ativo": form.get("ativo") == "on",
    }
    return doc, erros


@app.template_filter("brl")
def formatar_brl(valor):
    texto = f"{float(valor or 0):,.2f}"
    return "R$ " + texto.replace(",", "X").replace(".", ",").replace("X", ".")


@app.template_filter("data")
def formatar_data(valor):
    return valor.strftime("%d/%m/%Y %H:%M") if valor else "-"


# ---------------------------------------------------------------- READ (lista)
@app.route("/")
def listar():
    q = request.args.get("q", "").strip()
    categoria = request.args.get("categoria", "").strip()
    tag = request.args.get("tag", "").strip()
    situacao = request.args.get("situacao", "")
    ordem = request.args.get("ordem", "nome")
    pagina = max(request.args.get("pagina", 1, type=int), 1)

    filtro = {}
    if q:
        padrao = {"$regex": re.escape(q), "$options": "i"}
        filtro["$or"] = [{"nome": padrao}, {"sku": padrao}, {"descricao": padrao}]
    if categoria:
        filtro["categoria"] = categoria
    if tag:
        filtro["tags"] = tag
    if situacao == "ativos":
        filtro["ativo"] = True
    elif situacao == "inativos":
        filtro["ativo"] = False
    elif situacao == "sem_estoque":
        filtro["estoque"] = {"$lte": 0}

    campo, direcao = ORDENACOES.get(ordem, ORDENACOES["nome"])
    total = produtos.count_documents(filtro)
    itens = list(
        produtos.find(filtro)
        .sort(campo, direcao)
        .skip((pagina - 1) * POR_PAGINA)
        .limit(POR_PAGINA)
    )
    paginas = max((total + POR_PAGINA - 1) // POR_PAGINA, 1)

    return render_template(
        "lista.html",
        itens=itens,
        total=total,
        pagina=pagina,
        paginas=paginas,
        categorias=sorted(produtos.distinct("categoria")),
        filtros={"q": q, "categoria": categoria, "tag": tag, "situacao": situacao, "ordem": ordem},
        consulta=filtro,
    )


# -------------------------------------------------------------------- CREATE
@app.route("/produtos/novo", methods=["GET", "POST"])
def novo():
    if request.method == "POST":
        doc, erros = ler_formulario(request.form)
        if not erros:
            doc["criado_em"] = doc["atualizado_em"] = agora()
            foto = salvar_foto(request.files.get("foto"), doc["sku"])
            if foto:
                doc["foto"] = foto
            try:
                resultado = produtos.insert_one(doc)
                flash(f"Produto cadastrado (_id {resultado.inserted_id}).", "ok")
                return redirect(url_for("detalhe", id=resultado.inserted_id))
            except DuplicateKeyError:
                erros.append(f"Já existe um produto com o SKU {doc['sku']}.")
        for erro in erros:
            flash(erro, "erro")
        return render_template("form.html", produto=doc, titulo="Novo produto"), 400
    vazio = {"ativo": True, "fornecedor": {}, "especificacoes": {}, "tags": []}
    return render_template("form.html", produto=vazio, titulo="Novo produto")


# ------------------------------------------------------------ READ (detalhe)
@app.route("/produtos/<id>")
def detalhe(id):
    return render_template("detalhe.html", p=buscar_ou_404(id))


# -------------------------------------------------------------------- UPDATE
@app.route("/produtos/<id>/editar", methods=["GET", "POST"])
def editar(id):
    atual = buscar_ou_404(id)
    if request.method == "POST":
        doc, erros = ler_formulario(request.form)
        if not erros:
            doc["atualizado_em"] = agora()
            alteracao = {"$set": doc}
            foto = salvar_foto(request.files.get("foto"), doc["sku"])
            if foto:
                doc["foto"] = foto
            elif request.form.get("remover_foto") == "on":
                alteracao["$unset"] = {"foto": ""}
            try:
                produtos.update_one({"_id": atual["_id"]}, alteracao)
                flash("Produto atualizado.", "ok")
                return redirect(url_for("detalhe", id=id))
            except DuplicateKeyError:
                erros.append(f"Já existe um produto com o SKU {doc['sku']}.")
        for erro in erros:
            flash(erro, "erro")
        doc["_id"] = atual["_id"]
        doc["foto"] = atual.get("foto")
        return render_template("form.html", produto=doc, titulo="Editar produto"), 400
    return render_template("form.html", produto=atual, titulo="Editar produto")


@app.route("/produtos/<id>/estoque", methods=["POST"])
def ajustar_estoque(id):
    """Entrada/saída de estoque com o operador atômico $inc."""
    quantidade = request.form.get("quantidade", 0, type=int)
    filtro = {"_id": obter_id(id)}
    if quantidade < 0:
        filtro["estoque"] = {"$gte": -quantidade}  # não deixa o estoque ficar negativo
    resultado = produtos.update_one(
        filtro, {"$inc": {"estoque": quantidade}, "$set": {"atualizado_em": agora()}}
    )
    if resultado.modified_count:
        flash(f"Estoque ajustado em {quantidade:+d}.", "ok")
    else:
        flash("Estoque insuficiente para essa saída.", "erro")
    return redirect(url_for("detalhe", id=id))


@app.route("/produtos/<id>/tags", methods=["POST"])
def alterar_tag(id):
    """Inclui ($addToSet) ou remove ($pull) um elemento do array de tags."""
    tag = request.form.get("tag", "").strip().lower()
    if tag:
        operador = "$pull" if request.form.get("acao") == "remover" else "$addToSet"
        produtos.update_one(
            {"_id": obter_id(id)}, {operador: {"tags": tag}, "$set": {"atualizado_em": agora()}}
        )
    return redirect(url_for("detalhe", id=id))


# -------------------------------------------------------------------- DELETE
@app.route("/produtos/<id>/excluir", methods=["POST"])
def excluir(id):
    resultado = produtos.delete_one({"_id": obter_id(id)})
    if resultado.deleted_count:
        flash("Produto excluído.", "ok")
    return redirect(url_for("listar"))


# --------------------------------------------------------------- AGGREGATION
@app.route("/relatorio")
def relatorio():
    pipeline = [
        {"$group": {
            "_id": "$categoria",
            "produtos": {"$sum": 1},
            "itens_em_estoque": {"$sum": "$estoque"},
            "valor_em_estoque": {"$sum": {"$multiply": ["$preco", "$estoque"]}},
            "preco_medio": {"$avg": "$preco"},
            "preco_min": {"$min": "$preco"},
            "preco_max": {"$max": "$preco"},
        }},
        {"$sort": {"valor_em_estoque": -1}},
    ]
    por_categoria = list(produtos.aggregate(pipeline))
    tags = list(produtos.aggregate([
        {"$unwind": "$tags"},
        {"$group": {"_id": "$tags", "total": {"$sum": 1}}},
        {"$sort": {"total": -1, "_id": 1}},
        {"$limit": 10},
    ]))
    return render_template("relatorio.html", por_categoria=por_categoria, tags=tags, pipeline=pipeline)


# ----------------------------------------------------------------- DASHBOARD
def pipeline_dashboard():
    """Um único aggregate com $facet devolve todos os blocos do dashboard."""
    valor = {"$multiply": ["$preco", "$estoque"]}
    return [{"$facet": {
        "resumo": [{"$group": {
            "_id": None,
            "produtos": {"$sum": 1},
            "ativos": {"$sum": {"$cond": ["$ativo", 1, 0]}},
            "itens": {"$sum": "$estoque"},
            "valor": {"$sum": valor},
            "preco_medio": {"$avg": "$preco"},
            "sem_estoque": {"$sum": {"$cond": [{"$lte": ["$estoque", 0]}, 1, 0]}},
            "estoque_baixo": {"$sum": {"$cond": [
                {"$and": [{"$gt": ["$estoque", 0]}, {"$lte": ["$estoque", ESTOQUE_BAIXO]}]}, 1, 0]}},
        }}],
        "categorias": [
            {"$group": {"_id": "$categoria", "produtos": {"$sum": 1},
                        "itens": {"$sum": "$estoque"}, "valor": {"$sum": valor}}},
            {"$sort": {"valor": -1}},
        ],
        "faixas": [{"$bucket": {
            "groupBy": "$preco", "boundaries": FAIXAS_PRECO, "default": "acima",
            "output": {"produtos": {"$sum": 1}},
        }}],
        "fornecedores": [
            {"$group": {"_id": "$fornecedor.nome", "produtos": {"$sum": 1}, "valor": {"$sum": valor}}},
            {"$sort": {"valor": -1}},
            {"$limit": 5},
        ],
        "tags": [
            {"$unwind": "$tags"},
            {"$group": {"_id": "$tags", "total": {"$sum": 1}}},
            {"$sort": {"total": -1, "_id": 1}},
            {"$limit": 8},
        ],
        "repor": [
            {"$match": {"ativo": True, "estoque": {"$lte": ESTOQUE_BAIXO}}},
            {"$sort": {"estoque": 1, "nome": 1}},
            {"$limit": 6},
            {"$project": {"sku": 1, "nome": 1, "categoria": 1, "estoque": 1, "foto": 1}},
        ],
        "recentes": [
            {"$sort": {"atualizado_em": -1}},
            {"$limit": 5},
            {"$project": {"sku": 1, "nome": 1, "categoria": 1, "preco": 1, "atualizado_em": 1, "foto": 1}},
        ],
    }}]


def com_percentual(linhas, campo):
    """Acrescenta 'pct' (0-100) a cada linha, relativo ao maior valor do campo."""
    maior = max((linha.get(campo) or 0 for linha in linhas), default=0)
    for linha in linhas:
        linha["pct"] = round(100 * (linha.get(campo) or 0) / maior, 1) if maior else 0
    return linhas


@app.route("/dashboard")
def dashboard():
    pipeline = pipeline_dashboard()
    dados = next(iter(produtos.aggregate(pipeline)), {})
    resumo = (dados.get("resumo") or [{}])[0]
    total = resumo.get("produtos", 0)

    contagem = {f["_id"]: f["produtos"] for f in dados.get("faixas", [])}
    faixas = com_percentual(
        [{"rotulo": rotulo, "produtos": contagem.get(chave, 0)} for chave, rotulo in ROTULOS_FAIXA.items()],
        "produtos",
    )

    sem = resumo.get("sem_estoque", 0)
    baixo = resumo.get("estoque_baixo", 0)
    situacao = [
        {"chave": "ok", "icone": "✓", "rotulo": "Em estoque", "total": total - sem - baixo},
        {"chave": "baixo", "icone": "!", "rotulo": f"Estoque baixo (até {ESTOQUE_BAIXO})", "total": baixo},
        {"chave": "zerado", "icone": "✕", "rotulo": "Sem estoque", "total": sem},
    ]
    for item in situacao:
        item["pct"] = round(100 * item["total"] / total, 1) if total else 0

    return render_template(
        "dashboard.html",
        resumo=resumo,
        total=total,
        categorias=com_percentual(dados.get("categorias", []), "valor"),
        fornecedores=com_percentual(dados.get("fornecedores", []), "valor"),
        faixas=faixas,
        situacao=situacao,
        tags=dados.get("tags", []),
        repor=dados.get("repor", []),
        recentes=dados.get("recentes", []),
        limite=ESTOQUE_BAIXO,
        pipeline=pformat(pipeline, width=100, sort_dicts=False),
    )


@app.errorhandler(404)
def nao_encontrado(_erro):
    return render_template("404.html"), 404


if __name__ == "__main__":
    criar_indices()
    app.run(debug=True, port=5000)
