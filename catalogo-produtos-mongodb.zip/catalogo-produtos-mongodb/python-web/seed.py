"""Popula o banco 'catalogo' com produtos de exemplo (insert_many).

Uso: python seed.py          -> insere os exemplos se a coleção estiver vazia
     python seed.py --reset  -> apaga tudo (delete_many) e insere de novo
"""
import sys
from datetime import datetime, timezone

from app import criar_indices, produtos

AGORA = datetime.now(timezone.utc)


def p(sku, nome, categoria, preco, estoque, tags, fornecedor, cidade, especificacoes, descricao="", ativo=True):
    return {
        "sku": sku, "nome": nome, "descricao": descricao, "categoria": categoria,
        "preco": preco, "estoque": estoque, "tags": tags,
        "fornecedor": {"nome": fornecedor, "cidade": cidade},
        "especificacoes": especificacoes, "ativo": ativo,
        "criado_em": AGORA, "atualizado_em": AGORA,
    }


EXEMPLOS = [
    p("ELE-0001", "Mouse sem fio M185", "Eletrônicos", 79.90, 42, ["sem fio", "periférico"], "TechDistribuidora", "São Paulo",
      {"cor": "preto", "conexao": "USB 2.4 GHz", "pilha": "1x AA"}, "Mouse óptico compacto"),
    p("ELE-0002", "Teclado mecânico K552", "Eletrônicos", 289.00, 15, ["periférico", "gamer"], "TechDistribuidora", "São Paulo",
      {"switch": "blue", "layout": "ABNT2", "iluminacao": "RGB"}),
    p("ELE-0003", "Monitor 24\" Full HD", "Eletrônicos", 749.90, 8, ["promoção"], "VisionBR", "Campinas",
      {"painel": "IPS", "taxa_atualizacao": "75 Hz", "entradas": "HDMI, VGA"}),
    p("ELE-0004", "Webcam HD 720p", "Eletrônicos", 129.50, 0, ["periférico"], "VisionBR", "Campinas",
      {"resolucao": "1280x720", "microfone": "embutido"}),
    p("ESC-0001", "Caderno universitário 200 fls", "Escritório", 24.90, 120, ["papelaria"], "Papel & Cia", "Marília",
      {"folhas": "200", "capa": "dura"}),
    p("ESC-0002", "Caneta esferográfica azul (cx 50)", "Escritório", 39.00, 60, ["papelaria", "promoção"], "Papel & Cia", "Marília",
      {"ponta": "1.0 mm", "quantidade": "50"}),
    p("ESC-0003", "Cadeira ergonômica", "Escritório", 899.00, 5, ["móveis"], "Conforto Móveis", "Bauru",
      {"peso_maximo": "120 kg", "ajuste_altura": "sim", "cor": "preta"}),
    p("CAS-0001", "Cafeteira elétrica 30 xícaras", "Casa", 159.90, 18, ["cozinha"], "EletroLar", "Ribeirão Preto",
      {"voltagem": "127 V", "potencia": "800 W"}),
    p("CAS-0002", "Jogo de panelas 5 peças", "Casa", 219.00, 9, ["cozinha", "promoção"], "EletroLar", "Ribeirão Preto",
      {"material": "alumínio antiaderente", "pecas": "5"}),
    p("CAS-0003", "Ventilador de mesa 40 cm", "Casa", 189.90, 0, ["clima"], "EletroLar", "Ribeirão Preto",
      {"voltagem": "bivolt", "velocidades": "3"}, ativo=False),
    p("AGR-0001", "Sensor de umidade do solo", "Agro", 349.00, 25, ["iot", "sensor"], "AgroSense", "Tupã",
      {"faixa": "0-100 %", "comunicacao": "LoRa", "bateria": "2 anos"}),
    p("AGR-0002", "Estação meteorológica compacta", "Agro", 2490.00, 3, ["iot", "sensor"], "AgroSense", "Tupã",
      {"sensores": "temperatura, umidade, vento, chuva", "alimentacao": "solar"}),
]

if __name__ == "__main__":
    criar_indices()
    if "--reset" in sys.argv:
        apagados = produtos.delete_many({}).deleted_count
        print(f"{apagados} documento(s) removido(s).")
    if produtos.count_documents({}) == 0:
        resultado = produtos.insert_many(EXEMPLOS)
        print(f"{len(resultado.inserted_ids)} produto(s) inserido(s).")
    else:
        print("A coleção já tem dados. Use --reset para recriar.")
