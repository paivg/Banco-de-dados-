package ial215.catalogo;

import static com.mongodb.client.model.Accumulators.avg;
import static com.mongodb.client.model.Accumulators.sum;
import static com.mongodb.client.model.Filters.and;
import static com.mongodb.client.model.Filters.eq;
import static com.mongodb.client.model.Filters.gte;
import static com.mongodb.client.model.Filters.regex;
import static com.mongodb.client.model.Updates.combine;
import static com.mongodb.client.model.Updates.inc;
import static com.mongodb.client.model.Updates.set;

import com.mongodb.MongoWriteException;
import com.mongodb.client.MongoClient;
import com.mongodb.client.MongoClients;
import com.mongodb.client.MongoCollection;
import com.mongodb.client.model.Aggregates;
import com.mongodb.client.model.IndexOptions;
import com.mongodb.client.model.Indexes;
import com.mongodb.client.model.Sorts;
import com.mongodb.client.result.DeleteResult;
import com.mongodb.client.result.UpdateResult;
import java.util.Arrays;
import java.util.Date;
import java.util.List;
import java.util.Scanner;
import org.bson.Document;
import org.bson.conversions.Bson;

/**
 * Cliente de console do Catálogo de Produtos (driver oficial MongoDB para Java).
 * Usa o mesmo banco ("catalogo") e a mesma coleção ("produtos") da aplicação web em Python.
 */
public class CatalogoCli {

    private static final Scanner ENTRADA = new Scanner(System.in);
    private static MongoCollection<Document> produtos;

    public static void main(String[] args) {
        String uri = System.getenv().getOrDefault("MONGO_URI", "mongodb://localhost:27017");
        String banco = System.getenv().getOrDefault("MONGO_DB", "catalogo");

        try (MongoClient cliente = MongoClients.create(uri)) {
            produtos = cliente.getDatabase(banco).getCollection("produtos");
            produtos.createIndex(Indexes.ascending("sku"), new IndexOptions().unique(true).name("sku_unico"));
            System.out.println("Conectado em " + uri + " / " + banco + ".produtos");

            while (true) {
                System.out.println("\n=== CATALOGO DE PRODUTOS (Java) ===");
                System.out.println("1 - Listar produtos");
                System.out.println("2 - Buscar por nome");
                System.out.println("3 - Inserir produto");
                System.out.println("4 - Atualizar preco");
                System.out.println("5 - Ajustar estoque");
                System.out.println("6 - Excluir produto");
                System.out.println("7 - Relatorio por categoria");
                System.out.println("0 - Sair");
                switch (ler("Opcao")) {
                    case "1" -> listar(new Document());
                    case "2" -> listar(regex("nome", java.util.regex.Pattern.quote(ler("Trecho do nome")), "i"));
                    case "3" -> inserir();
                    case "4" -> atualizarPreco();
                    case "5" -> ajustarEstoque();
                    case "6" -> excluir();
                    case "7" -> relatorio();
                    case "0" -> { return; }
                    default -> System.out.println("Opcao invalida.");
                }
            }
        }
    }

    // ------------------------------------------------------------------ READ
    private static void listar(Bson filtro) {
        System.out.printf("%-10s %-36s %-14s %12s %8s%n", "SKU", "NOME", "CATEGORIA", "PRECO", "ESTOQUE");
        int total = 0;
        for (Document p : produtos.find(filtro).sort(Sorts.ascending("nome"))) {
            System.out.printf("%-10s %-36s %-14s %12.2f %8d%n",
                    p.getString("sku"), cortar(p.getString("nome"), 36), cortar(p.getString("categoria"), 14),
                    numero(p.get("preco")), ((Number) p.get("estoque")).intValue());
            total++;
        }
        System.out.println(total + " documento(s).");
    }

    // ---------------------------------------------------------------- CREATE
    private static void inserir() {
        Date agora = new Date();
        Document doc = new Document("sku", ler("SKU").toUpperCase())
                .append("nome", ler("Nome"))
                .append("descricao", ler("Descricao"))
                .append("categoria", ler("Categoria"))
                .append("preco", lerDecimal("Preco"))
                .append("estoque", lerInteiro("Estoque"))
                .append("tags", lerLista("Tags (separadas por virgula)"))
                .append("fornecedor", new Document("nome", ler("Fornecedor")).append("cidade", ler("Cidade do fornecedor")))
                .append("especificacoes", new Document())
                .append("ativo", true)
                .append("criado_em", agora)
                .append("atualizado_em", agora);
        try {
            produtos.insertOne(doc);
            System.out.println("Inserido com _id " + doc.getObjectId("_id"));
        } catch (MongoWriteException e) {
            System.out.println("Nao inserido: " + e.getError().getMessage());
        }
    }

    // ---------------------------------------------------------------- UPDATE
    private static void atualizarPreco() {
        String sku = ler("SKU").toUpperCase();
        UpdateResult r = produtos.updateOne(eq("sku", sku),
                combine(set("preco", lerDecimal("Novo preco")), set("atualizado_em", new Date())));
        System.out.println(r.getMatchedCount() == 0 ? "SKU nao encontrado." : "Preco atualizado.");
    }

    private static void ajustarEstoque() {
        String sku = ler("SKU").toUpperCase();
        int quantidade = lerInteiro("Quantidade (+ entrada, - saida)");
        Bson filtro = quantidade < 0 ? and(eq("sku", sku), gte("estoque", -quantidade)) : eq("sku", sku);
        UpdateResult r = produtos.updateOne(filtro,
                combine(inc("estoque", quantidade), set("atualizado_em", new Date())));
        System.out.println(r.getModifiedCount() == 0 ? "Nada alterado (SKU inexistente ou estoque insuficiente)." : "Estoque ajustado.");
    }

    // ---------------------------------------------------------------- DELETE
    private static void excluir() {
        DeleteResult r = produtos.deleteOne(eq("sku", ler("SKU").toUpperCase()));
        System.out.println(r.getDeletedCount() == 0 ? "SKU nao encontrado." : "Produto excluido.");
    }

    // ----------------------------------------------------------- AGGREGATION
    private static void relatorio() {
        List<Bson> pipeline = Arrays.asList(
                Aggregates.group("$categoria",
                        sum("produtos", 1),
                        sum("itens", "$estoque"),
                        sum("valor", new Document("$multiply", Arrays.asList("$preco", "$estoque"))),
                        avg("preco_medio", "$preco")),
                Aggregates.sort(Sorts.descending("valor")));
        System.out.printf("%-14s %9s %8s %14s %12s%n", "CATEGORIA", "PRODUTOS", "ITENS", "VALOR ESTOQUE", "PRECO MEDIO");
        for (Document c : produtos.aggregate(pipeline)) {
            System.out.printf("%-14s %9d %8d %14.2f %12.2f%n",
                    cortar(c.getString("_id"), 14), ((Number) c.get("produtos")).intValue(),
                    ((Number) c.get("itens")).intValue(), numero(c.get("valor")), numero(c.get("preco_medio")));
        }
    }

    // --------------------------------------------------------------- utilitarios
    private static String ler(String rotulo) {
        System.out.print(rotulo + ": ");
        return ENTRADA.hasNextLine() ? ENTRADA.nextLine().trim() : "0";
    }

    private static double lerDecimal(String rotulo) {
        while (true) {
            try {
                return Double.parseDouble(ler(rotulo).replace(",", "."));
            } catch (NumberFormatException e) {
                System.out.println("Numero invalido.");
            }
        }
    }

    private static int lerInteiro(String rotulo) {
        while (true) {
            try {
                return Integer.parseInt(ler(rotulo));
            } catch (NumberFormatException e) {
                System.out.println("Numero invalido.");
            }
        }
    }

    private static List<String> lerLista(String rotulo) {
        return Arrays.stream(ler(rotulo).split(","))
                .map(String::trim).map(String::toLowerCase).filter(s -> !s.isEmpty()).toList();
    }

    private static double numero(Object valor) {
        return valor instanceof Number n ? n.doubleValue() : 0.0;
    }

    private static String cortar(String texto, int tamanho) {
        if (texto == null) return "";
        return texto.length() <= tamanho ? texto : texto.substring(0, tamanho - 1) + "…";
    }
}
