# Catálogo de Produtos — CRUD com MongoDB

Atividade Prática da disciplina **IAL-215 – Banco de Dados NoSQL**.

Aplicação CRUD de catálogo de produtos com dados persistidos em **MongoDB**, em duas partes que usam o mesmo banco (`catalogo`) e a mesma coleção (`produtos`):

| Pasta | O que é | Tecnologias |
| --- | --- | --- |
| `python-web/` | Aplicação web com as telas (dashboard, lista, cadastro, edição, detalhe, relatório) | Python, Flask, PyMongo |
| `java-cli/` | Cliente de console com o mesmo CRUD | Java 17, Maven, driver oficial `mongodb-driver-sync` |
| `mongosh/` | Comandos de evidência para rodar direto no shell do banco | mongosh |

## Integrantes

- _Nome completo — RA_
- _Nome completo — RA_
- _Nome completo — RA_
- _Nome completo — RA_

## Modelo do documento

```json
{
  "_id": ObjectId("..."),
  "sku": "ELE-0001",
  "nome": "Mouse sem fio M185",
  "descricao": "Mouse óptico compacto",
  "categoria": "Eletrônicos",
  "preco": 79.9,
  "estoque": 42,
  "tags": ["sem fio", "periférico"],
  "fornecedor": { "nome": "TechDistribuidora", "cidade": "São Paulo" },
  "especificacoes": { "cor": "preto", "conexao": "USB 2.4 GHz" },
  "ativo": true,
  "criado_em": ISODate("..."),
  "atualizado_em": ISODate("...")
}
```

Recursos do MongoDB usados: documento embutido (`fornecedor`), campos livres sem esquema fixo (`especificacoes`), array (`tags`), índice único (`sku`), índice de texto, índice composto, `$regex`, `$set`, `$inc`, `$addToSet`, `$pull` e Aggregation Pipeline (`$facet`, `$group`, `$bucket`, `$cond`, `$unwind`, `$sort`, `$limit`).

## Pré-requisitos

- MongoDB Community Server rodando em `mongodb://localhost:27017` (e `mongosh` ou MongoDB Compass para as evidências)
- Python 3.10+
- Java 17+ e Maven 3.8+

Para usar outro servidor, defina a variável de ambiente `MONGO_URI` (e, se quiser, `MONGO_DB`).

## Aplicação web (Python)

```bash
cd python-web
python -m venv .venv
# Windows: .venv\Scripts\activate      Linux/macOS: source .venv/bin/activate
pip install -r requirements.txt
python seed.py        # insere 12 produtos de exemplo (use --reset para recriar)
python app.py         # http://localhost:5000/dashboard
```

| Operação | Rota | Comando PyMongo |
| --- | --- | --- |
| Create | `POST /produtos/novo` | `insert_one` |
| Read | `GET /`, `GET /produtos/<id>` | `find`, `find_one`, `count_documents`, `distinct` |
| Update | `POST /produtos/<id>/editar` | `update_one` com `$set` |
| Update | `POST /produtos/<id>/estoque` | `update_one` com `$inc` |
| Update | `POST /produtos/<id>/tags` | `update_one` com `$addToSet` / `$pull` |
| Delete | `POST /produtos/<id>/excluir` | `delete_one` |
| Relatório | `GET /relatorio` | `aggregate` |
| Dashboard | `GET /dashboard` | um único `aggregate` com `$facet`, `$bucket`, `$cond`, `$unwind` |

No Windows, basta dar dois cliques em `rodar-web.bat` (aplicação web) ou `rodar-java.bat` (cliente Java).

## Cliente de console (Java)

```bash
cd java-cli
mvn compile exec:java
```

Menu: listar, buscar por nome, inserir, atualizar preço, ajustar estoque, excluir e relatório por categoria (`insertOne`, `find`, `updateOne`, `deleteOne`, `aggregate`).

## Evidências no banco

```bash
mongosh --file mongosh/comandos.js
```

Ou abra o `mongosh`, digite `use catalogo` e rode os comandos do arquivo um a um. No MongoDB Compass, conecte em `mongodb://localhost:27017` e abra `catalogo > produtos`.
