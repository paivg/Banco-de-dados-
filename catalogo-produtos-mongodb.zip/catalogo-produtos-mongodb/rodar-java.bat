@echo off
title Catalogo de Produtos - Java
cd /d "%~dp0java-cli"

where mvn >nul 2>nul
if errorlevel 1 (
  echo [ERRO] Maven nao encontrado. Instale o Maven e o JDK 17 ou superior e tente de novo.
  pause
  exit /b 1
)

call mvn -q compile exec:java
pause
